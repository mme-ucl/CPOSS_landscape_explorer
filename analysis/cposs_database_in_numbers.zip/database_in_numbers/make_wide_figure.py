"""Rearrange the reviewed vector figure into three columns and two rows.

Every panel is translated at its original physical size. No plot is redrawn,
scaled, rotated or rasterised. Re-run this after rebuilding the portrait PDF.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

from PIL import Image
from pypdf import PdfReader, PdfWriter, Transformation
from pypdf.generic import RectangleObject


BASE = Path(__file__).resolve().parent


def main():
    source = BASE / "output/pdf/database_in_numbers.pdf"
    output = source.with_name("database_in_numbers_3x2.pdf")
    png = BASE / "figures/database_in_numbers_3x2.png"
    pdftoppm = shutil.which("pdftoppm")
    if pdftoppm is None:
        raise RuntimeError("pdftoppm is required to render and verify the result")

    reader = PdfReader(source)
    if len(reader.pages) != 1 or reader.pages[0].rotation:
        raise ValueError("Expected the reviewed, unrotated, single-page figure")
    original = reader.pages[0]
    width, height = float(original.mediabox.width), float(original.mediabox.height)
    if len(original.images):
        raise ValueError("Expected the original vector figure without raster images")

    # Original panel heading anchors and crop boundaries, in page fractions.
    # Crops include all axis labels, legends, headings and panel E's two notes.
    panels = {
        "A": (0.085, 0.884, 0.610),
        "B": (0.530, 0.884, 0.610),
        "C": (0.085, 0.596, 0.330),
        "D": (0.530, 0.596, 0.330),
        "E": (0.085, 0.314, 0.027),
        "F": (0.530, 0.314, 0.027),
    }
    margin, gutter, heading_padding = 12.0, 18.0, 5.0
    panel_width = 0.425 * width
    first_row_depth = max((panels[p][1] - panels[p][2]) * height for p in "ABC")
    second_row_depth = max((panels[p][1] - panels[p][2]) * height for p in "DEF")
    row_pitch = first_row_depth + 26.0
    header_depth = (1 - panels["A"][1]) * height
    canvas_width = 2 * margin + 3 * panel_width + 2 * gutter
    canvas_height = header_depth + row_pitch + second_row_depth + margin
    row_headings = [canvas_height - header_depth, margin + second_row_depth]

    writer = PdfWriter()
    writer.pdf_header = reader.pdf_header
    page = writer.add_blank_page(width=canvas_width, height=canvas_height)
    placements = {}

    def place(name, bounds, dx, dy):
        tile = copy.copy(original)
        tile.cropbox = RectangleObject(bounds)
        tile.trimbox = RectangleObject(bounds)
        transform = Transformation().translate(tx=dx, ty=dy)
        if transform.ctm[:4] != (1, 0, 0, 1):
            raise AssertionError("Only translations are allowed")
        page.merge_transformed_page(tile, transform, expand=False)
        destination = [bounds[0] + dx, bounds[1] + dy, bounds[2] + dx, bounds[3] + dy]
        if not (0 <= destination[0] < destination[2] <= canvas_width + 1e-8
                and 0 <= destination[1] < destination[3] <= canvas_height + 1e-8):
            raise AssertionError(f"Content outside the destination page: {name}")
        placements[name] = {
            "source_crop_pt": list(bounds),
            "translation_pt": [dx, dy],
            "destination_crop_pt": destination,
            "scale_x": 1,
            "scale_y": 1,
            "rotation_degrees": 0,
        }

    # Recenter the complete title and summary strip without changing their size.
    place("header", (0, 0.895 * height, width, height),
          (canvas_width - width) / 2, canvas_height - height)
    for index, (name, (heading_x, heading_y, bottom)) in enumerate(panels.items()):
        row, column = divmod(index, 3)
        left = heading_x * width - heading_padding
        bounds = (left, bottom * height, left + panel_width,
                  heading_y * height + heading_padding)
        destination_left = margin + column * (panel_width + gutter)
        place(name, bounds, destination_left - left,
              row_headings[row] - heading_y * height)

    metadata = {key: value for key, value in (reader.metadata or {}).items()
                if isinstance(value, str)}
    metadata["/Subject"] = "CPOSS database in numbers; three columns by two rows; unchanged vector panels"
    writer.add_metadata(metadata)
    page.compress_content_streams()
    writer.compress_identical_objects()
    with output.open("wb") as stream:
        writer.write(stream)

    result = PdfReader(output)
    if len(result.pages) != 1 or result.pages[0].rotation or len(result.pages[0].images):
        raise AssertionError("Output must remain a single unrotated vector page")
    font_names = []
    for font_ref in result.pages[0]["/Resources"]["/Font"].values():
        font = font_ref.get_object()
        font_names.append(str(font["/BaseFont"]))
        if "Helvetica" not in font_names[-1]:
            raise AssertionError("Original Helvetica fonts must be retained")
        for descendant_ref in font.get("/DescendantFonts", []):
            descriptor = descendant_ref.get_object()["/FontDescriptor"].get_object()
            if not any(key in descriptor for key in ("/FontFile", "/FontFile2", "/FontFile3")):
                raise AssertionError("Fonts must remain embedded")

    subprocess.run([pdftoppm, "-r", "300", "-singlefile", "-png", str(output),
                    str(png.with_suffix(""))], check=True)
    with Image.open(png) as preview:
        expected = [round(canvas_width / 72 * 300), round(canvas_height / 72 * 300)]
        if any(abs(actual - target) > 1 for actual, target in zip(preview.size, expected)):
            raise AssertionError("PNG dimensions must match the PDF at 300 dpi")
        dimensions = list(preview.size)

    verification = {
        "status": "passed",
        "source_pdf": str(source.relative_to(BASE)),
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "output_pdf": str(output.relative_to(BASE)),
        "output_sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
        "layout": [["A", "B", "C"], ["D", "E", "F"]],
        "page_size_pt": [canvas_width, canvas_height],
        "page_size_mm": [canvas_width / 72 * 25.4, canvas_height / 72 * 25.4],
        "png_dimensions": dimensions,
        "png_dpi": 300,
        "fonts": sorted(set(font_names)),
        "vector_graphics": True,
        "all_panel_scales_unchanged": True,
        "all_panel_rotations_zero": True,
        "placements": placements,
    }
    (BASE / "verification_3x2.json").write_text(json.dumps(verification, indent=2) + "\n")
    print(json.dumps({key: value for key, value in verification.items() if key != "placements"}, indent=2))


if __name__ == "__main__":
    main()
